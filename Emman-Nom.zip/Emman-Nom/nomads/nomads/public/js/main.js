(function () {
  'use strict';
  const HOURS = { weekday: [570, 1140], weekend: [570, 1200] }; // minutes from midnight, Asia/Manila
  const CATS = ['All', 'Burgers', 'Munchies & Salads', 'Waffles & Mains', 'Coffee & Drinks', 'Pastries & Desserts'];

  function updateStatus() {
    const pill = document.getElementById('status-pill');
    const p = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Manila', weekday: 'short', hour: 'numeric', minute: 'numeric', hour12: false }).formatToParts(new Date());
    const get = (t) => p.find((x) => x.type === t).value;
    const wk = get('weekday');
    const mins = (parseInt(get('hour'), 10) % 24) * 60 + parseInt(get('minute'), 10);
    const [open, close] = (wk === 'Sat' || wk === 'Sun') ? HOURS.weekend : HOURS.weekday;
    const isOpen = mins >= open && mins < close;
    pill.textContent = isOpen ? 'OPEN NOW' : 'CLOSED';
    pill.className = 'pill ' + (isOpen ? 'open' : 'closed');
  }

  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let menu = [];
  let active = 'All';

  function renderMenu() {
    const grid = document.getElementById('menu-grid');
    const items = active === 'All' ? menu : menu.filter((i) => i.category === active);
    grid.innerHTML = items.map((i) => {
      const hasPrice = i.price !== null && i.price !== undefined && i.price !== '';
      const label = typeof i.price === 'number' ? '\u20B1' + i.price : i.price;
      const price = hasPrice
        ? `<span class="price">${esc(label)}</span>`
        : '<span class="price ask">ASK IN-STORE</span>';
      const thumb = i.image ? `<div class="thumb"><img src="${esc(i.image)}" alt="${esc(i.name)}" loading="lazy" onerror="this.parentNode.remove()"></div>` : '';
      return `<div class="col-md-6 col-xl-4"><article class="item">${thumb}<div class="body"><span class="cat">${esc(i.category)}</span><h3>${esc(i.name)}</h3><p>${esc(i.description || i.desc || "")}</p>${price}</div></article></div>`;
    }).join('');
  }

  function renderFilters() {
    const box = document.getElementById('filters');
    box.innerHTML = CATS.map((c) => `<button type="button" class="${c === active ? 'active' : ''}" aria-pressed="${c === active}" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
    box.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
      active = b.dataset.cat;
      renderFilters();
      renderMenu();
    }));
  }

  async function loadMenu() {
    renderFilters();
    try {
      const r = await fetch('data/menu.json');
      if (!r.ok) throw new Error('menu');
      menu = await r.json();
      renderMenu();
    } catch (e) {
      document.getElementById('menu-grid').innerHTML = '<p class="mono">Menu could not load. Refresh the page to try again.</p>';
    }
  }

  function initForm() {
    const form = document.getElementById('inquiry-form');
    const btn = document.getElementById('submit-btn');
    const msg = document.getElementById('form-msg');
    const show = (cls, text) => { msg.className = 'form-msg mono ' + cls; msg.textContent = text; };
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      if (!data.name.trim() || !data.contact.trim() || !data.type || !data.details.trim()) {
        return show('err', 'Fill in your name, contact, inquiry type and details.');
      }
      btn.disabled = true;
      const label = btn.textContent;
      btn.textContent = 'Sending…';
      msg.className = 'form-msg mono';
      try {
        const r = await fetch('/api/inquiry', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
        const j = await r.json().catch(() => ({}));
        if (!r.ok || !j.ok) throw new Error((j.errors || ['Something went wrong. Try again.']).join(' '));
        show('ok', 'Inquiry sent. We will reach out through your contact.');
        form.reset();
      } catch (err) {
        show('err', err.message || 'Could not send. Check your connection and try again.');
      } finally {
        btn.disabled = false;
        btn.textContent = label;
      }
    });
  }

  document.getElementById('yr').textContent = new Date().getFullYear();
  updateStatus();
  setInterval(updateStatus, 30000);
  function initNav() {
    const links = [...document.querySelectorAll('.nav-brut .nav-link')];
    const map = new Map(links.map((l) => [l.getAttribute('href').slice(1), l]));
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting && map.has(e.target.id)) { links.forEach((l) => l.classList.remove('active')); map.get(e.target.id).classList.add('active'); }
    }), { rootMargin: '-45% 0px -50% 0px' });
    map.forEach((_, id) => { const el = document.getElementById(id); if (el) io.observe(el); });
    document.querySelectorAll('#nav a').forEach((a) => a.addEventListener('click', () => {
      const c = document.getElementById('nav');
      if (c.classList.contains('show')) bootstrap.Collapse.getOrCreateInstance(c).hide();
    }));
  }
  loadMenu();
  initForm();
  initNav();
})();
