require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const TYPES = ['Bulk Order', 'Pre-Order', 'Table Reservation', 'Event / Group', 'Other'];

app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const clean = (v, max) => String(v || '').replace(/[<>]/g, '').trim().slice(0, max);

app.post('/api/inquiry', async (req, res) => {
  const b = req.body || {};
  const data = {
    name: clean(b.name, 80),
    contact: clean(b.contact, 120),
    type: clean(b.type, 40),
    datetime: clean(b.datetime, 40),
    details: clean(b.details, 1000),
    receivedAt: new Date().toISOString()
  };
  const errors = [];
  if (data.name.length < 2) errors.push('Name is required.');
  if (data.contact.length < 5) errors.push('Enter a phone number or Messenger link.');
  if (!TYPES.includes(data.type)) errors.push('Choose an inquiry type.');
  if (data.details.length < 5) errors.push('Add a few details.');
  if (errors.length) return res.status(400).json({ ok: false, errors });

  const url = process.env.WEBHOOK_URL;
  if (!url) {
    console.log('[INQUIRY - WEBHOOK_URL not set]', JSON.stringify(data));
    return res.json({ ok: true, delivered: false });
  }
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: `New inquiry: ${data.type}\nName: ${data.name}\nContact: ${data.contact}\nDate/Time: ${data.datetime || 'n/a'}\nDetails: ${data.details}`,
        ...data
      })
    });
    if (!r.ok) throw new Error('Webhook responded ' + r.status);
    res.json({ ok: true, delivered: true });
  } catch (e) {
    console.error('[WEBHOOK FAILED]', e.message, JSON.stringify(data));
    res.status(502).json({ ok: false, errors: ['Could not send right now. Please message us on Facebook.'] });
  }
});

app.listen(PORT, () => console.log(`NOMADS Café running at http://localhost:${PORT}`));
